<?php


    /**
     * @author Sanan Saleem <sanan.fui@gmail.com>
     * 
     * @desc Cache whole project
     */


    if (!function_exists('apc_compile_file'))
        die('APC not installed');
   
    const SCRIPTS_DIR = '..';

    $files = find_all_files(SCRIPTS_DIR);
    
    print '<pre>';
        
    $templates = Array();
    $compiled = 0;
    foreach($files as $file)
    {
        
        print "Caching $file - " .( ($status=apc_compile_file($file)) ? 'successful' : '**FAILED**')."\n";
        $compiled += (int)$status;
    }
    
    print "Total fiels compiled - $compiled\n";
    
    print '</pre>';
    
    //print_r(apc_sma_info());
    

    
    function find_all_files($dir, $pattern='.php')
    {
        $result = Array();
        
        if (! ($root = @scandir($dir)))
            return $result;
        
        foreach ($root as $value)
        {
            if ($value === '.' || $value === '..'  || $value==='.git') {continue;}
            
            
            if (is_file("$dir/$value") AND preg_match('/'.$pattern.'/Usi', $value)) 
            {
                $result[]="$dir/$value";
                continue;
            }
            foreach (find_all_files("$dir/$value", $pattern) as $value)
            {
                $result[]=$value;
            }
        }
        return $result;
    } 


