<?php
    /*
     * radSYS - [knit] Template compiler v1.6
     * NOTE : do not modify this file! As it gets overwritten automatically
     *
     * TE file generated at : April 12, 2016 09:25:36AM
     */

    class radSYS_TE
    {
        
        public static function __callStatic($method, $args)
        {
            global $_APP, $_DATA, $_LANG, $_KEY, $_VAL, $_SYS;

            $THIS  = $args[0];
            $_DATA = $args[1];
            $_LANG = &$THIS->lang;
            $_SYS  = &$THIS->SYS;


            ob_start("radSYS_ob");

            switch($method) {

    
                /* footer - template */
                case 'footer':
                {
                    print "<div class=\"navbar navbar-default navbar-fixed-bottom\" style=\"height:50px;\">
    <div class=\"container\">
		<p class=\"navbar-text pull-left\">&copy; 2015 - No rights reserved - the dinner is served !
			<a href=\"#\" target=\"_blank\" >My Link</a>
		</p>
		<a href=\"http://aborder.org/files/radSYS/?MA\" class=\"navbar-btn btn-primary btn pull-right\">
			<span class=\"glyphicon glyphicon-object-align-bottom\"></span>  Download
		</a>
    </div>
</div>
";
                    break;
                }
        


                /* header - template */
                case 'header':
                {
                    print "<img src=\"{$_SYS->http_root}/assets/images/radsys-header.png\"/>
<style>
	/* navbar-band icon positioning fix - remove this CSS style when creating your own header */
	.navbar-brand img {
		margin-left: 5px;
		margin-top: 0px;
		margin-right: 5px;
	}
</style>

<nav class=\"navbar navbar-inverse\">
	<div class=\"container-fluid\">
		<div class=\"navbar-header\">
			<a class=\"navbar-brand\" href=\"{$_SYS->http_root}/../\">
				<img class=\"pull-left\" src=\"{$_SYS->http_root}/assets/images/radsys-logo-small.png\" width=\"24\" />
				<b>&copy; radSYS</b>
			</a>
		</div>
		<div class=\"collapse navbar-collapse\" id=\"myNavbar\">
			<ul class=\"nav navbar-nav\">
				<li class=\"active\"><a href=\"{$_SYS->http_root}/home\">Home</a></li>
			</ul>
		</div>
	</div>
</nav>
";
                    break;
                }
        


                /* layouts/api_restful - layout */
                case 'layouts_api_restful':
                {
                    print "<area:REST/>";
                    break;
                }
        


                /* layouts/default - layout */
                case 'layouts_default':
                {
                    print "<!DOCTYPE html>
<html>
	<head>
		<title>{$_APP['website_name']}</title>
		<meta charset=\"utf-8\" />
		<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
		<link rel=\"icon\" type=\"image/ico\" href=\"{$_SYS->http_root}/assets/icons/radsys-icon.ico\" />
		
		<link rel=\"stylesheet\" href=\"{$_SYS->http_root}/assets/css/bootstrap.min.css\" />

		<script src=\"{$_SYS->http_root}/assets/js/jquery.min.js\"></script>
		<script src=\"{$_SYS->http_root}/assets/js/bootstrap.min.js\"></script>
	</head>
	<body>
		".radSYS_TE::header ($THIS, $_DATA)."
			
		<div class=\"container\">
			<area:CONTENT />
		</div>
		
		".radSYS_TE::footer ($THIS, $_DATA)."
	</body>
</html>
";
                    break;
                }
        


                /* main - template */
                case 'main':
                {
                    print "<div class=\"jumbotron\">
    <div class=\"container-fluid\">
        <div class=\"row\">
            <div class=\"col-xs-8\">
                <h1><span style=\"color:#7592ff\"><b>radSYS 3.2</b></span></h1>
                <p>
                    <i>empty project $_DATA</i> - 
                </p>
                <ul>
                    <li>Edit ./application/views/main.html for this page html</li>
                    <li>Edit ./application/views/header.html for header part html</li>
                    <li>Edit ./application/views/footer.html for footer part html</li>
                    <li>Edit ./application/controllers/home.php for logic</li>
                </ul>
            </div>
            <div class=\"col-xs-4\">
                <p>Min Requirements:</p>
                <ul type=\"square\">
                    <li>PHP  &gt;= 5.4</li>
                    <li>Apache  2.x</li>
                    <li>MySQL / MariaDB 5.x</li>
                </ul>
                
                <p>3.2 - Roadmap:</p>
                <ul type=\"1\">
                    <li>N / A</li>
                </ul>
            </div>
        </div>
   </div>
</div>
";
                    break;
                }
        
                default:
                    print '{{invalid or missing template : '.$method."}}\n\n";
            }

            $conetents = ob_get_contents();
            ob_end_clean();

            return $conetents;
        }
    }


    if (!function_exists('radSYS_ob'))
    {
        function radSYS_ob($buffer)
        {
            return $buffer;
        }
    }

    /** Test of invalid template **/
    //uncomment following line to test TE alone
    //print radSYS_TE::invalid_template(NULL, NULL);

    