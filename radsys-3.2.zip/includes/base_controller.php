<?php

    /**
     * Extendible - general purpose controller
     */
    class Controller extends Basecontroller
    {
        /**
         * Developer additions
         */
    }




    /**
     * RESTFul interface
     */
    class ApiController extends ApiBaseController
    {
        const API_VERSION_MAJ = 7;
        const API_VERSION_MIN = 1;
        const API_ABOUT = 'radSYS 3.1';
        const API_LINK = 'http://www.aborder.org/files/radSYS';
        /**
         *
         */

    }
