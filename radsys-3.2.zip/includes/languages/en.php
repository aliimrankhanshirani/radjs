<?php

    $GLOBALS['Language'] = Array(
             99 => 'radSYS reserved till index # 100',
            100 => 'welcome to radSYS',
    ); 
    
    
   