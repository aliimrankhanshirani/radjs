<?php


    const DEV_MODE = FALSE; //FASE = Production
    const ERR_IDENTIFIER = 'radSYS_error~';

    /**
     * Application Settings
     */

    const DEFAULT_CONTROLLER = 'home';
    const DEFAULT_METHOD     = 'main';
    const DEFAULT_LANGUAGE   = 'en';


    /* database information */
    const DB_NAME = 'radsys';
    const DB_USER = 'root';
    const DB_PASS = '';
    const DB_HOST = 'localhost';


    /* general settings */

    const DEFAULT_REDIRECT_TIME = 2000;
    const CACHE_DIR = '../includes/syscache';
    const COOKIE_PATH = '/';
    const COOKIE_DOMAIN = '';

    const DEFAULT_SCHEME = 'http';

    /* cache settings */
    const OUTPUT_COMPRESSION = FALSE;


    $_APP['website_name'] = 'Video Project';
