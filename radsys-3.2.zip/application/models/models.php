<?php
    /*
     * radSYS - Modelizer v1.4 generated models from database 'radsys'
     * NOTE : do not modify this file! As it gets overwritten automatically
     */



        class User extends Model
        {
            public $table_name   = 'users';
            public $table_key    = 'id';
            public $table_fields = Array('id','name','email','password','creation_date','modification_date');
            public $field_types  = Array ( 'id' => Array ( 'type' => 'int', 'extra' => Array ( ), 'length' => 0, 'nullable' => false, 'key_type' => 'PRI', 'default' => NULL, ), 'name' => Array ( 'type' => 'varchar', 'extra' => Array ( ), 'length' => 45, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), 'email' => Array ( 'type' => 'varchar', 'extra' => Array ( ), 'length' => 50, 'nullable' => true, 'key_type' => 'UNI', 'default' => NULL, ), 'password' => Array ( 'type' => 'varchar', 'extra' => Array ( ), 'length' => 32, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), 'creation_date' => Array ( 'type' => 'timestamp', 'extra' => Array ( ), 'length' => 0, 'nullable' => false, 'key_type' => '', 'default' => 'CURRENT_TIMESTAMP', ), 'modification_date' => Array ( 'type' => 'timestamp', 'extra' => Array ( ), 'length' => 0, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), );

            /* for restful interface */
            public $mapables     = Array('videos');
            public function is_mapable($property)
            {
                return in_array($property, $this->mapables);
            }

            public static function get_empty()
            {
                return new User;
            }


            public function __get($property)
            {
                switch ($property)
                {

                    /* Child entities */

                    case 'videos' : return new Video("`user_id`='$this->id'");


                    default: return parent::__get($property);
                }
            }
        }
        


        class Video extends Model
        {
            public $table_name   = 'videos';
            public $table_key    = 'id';
            public $table_fields = Array('id','user_id','title','description','creation_date','modification_date');
            public $field_types  = Array ( 'id' => Array ( 'type' => 'int', 'extra' => Array ( ), 'length' => 0, 'nullable' => false, 'key_type' => 'PRI', 'default' => NULL, ), 'user_id' => Array ( 'type' => 'int', 'extra' => Array ( ), 'length' => 0, 'nullable' => false, 'key_type' => 'MUL', 'default' => NULL, ), 'title' => Array ( 'type' => 'varchar', 'extra' => Array ( ), 'length' => 45, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), 'description' => Array ( 'type' => 'varchar', 'extra' => Array ( ), 'length' => 50, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), 'creation_date' => Array ( 'type' => 'timestamp', 'extra' => Array ( ), 'length' => 0, 'nullable' => false, 'key_type' => '', 'default' => 'CURRENT_TIMESTAMP', ), 'modification_date' => Array ( 'type' => 'timestamp', 'extra' => Array ( ), 'length' => 0, 'nullable' => true, 'key_type' => '', 'default' => NULL, ), );

            /* for restful interface */
            public $mapables     = Array('users');
            public function is_mapable($property)
            {
                return in_array($property, $this->mapables);
            }

            public static function get_empty()
            {
                return new Video;
            }


            public function __get($property)
            {
                switch ($property)
                {

                    /* Parent entities */

                    case 'user' :   return new User("`id`='$this->user_id'");


                    default: return parent::__get($property);
                }
            }
        }
        


