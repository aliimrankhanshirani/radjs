<?php
    /*
     * radSYS - RIG - RESTFul Interface Generator v2.2
     * NOTE : do not modify this file! As it gets overwritten automatically
     * @author rig <radsys.com/doc>
     * @date March 15, 2016 01:15:06PM
     */

    require_once '../includes/settings_restful.php';

    class api extends ApiController
    {
        public  $layout = 'api_restful';
        private $entities = Array('files','groups','libraries','modules','permissions','project_users','projects','users');
        public  $map = Array();
        public  $hierarchical_data = Array();

        public function __call($entity, $args)
        {
            if (!in_array($entity, $this->entities))
            {
                $this->rest_format_data(
                    FALSE,
                    RESTFUL_NOTFOUND,
                    'Not found'
                );
                return;
            }

            $model_name = $this->entity_to_model($entity);
            $model = new $model_name;

            if (
                $this->SYS->request_method == 'GET' OR
                $this->SYS->request_method == 'DELETE' OR
                $this->SYS->request_method == 'PUT'
            )
            {
                if (!empty($this->ARGS))
                {
                    if (!is_numeric($this->ARGS[count($this->ARGS)-1]))
                        $GLOBALS['RestLastEntity'] = $this->ARGS[count($this->ARGS)-1];
                }
                else
                    $GLOBALS['RestLastEntity'] = $entity;

                if (!in_array($this->return, Array('normal','hierarchical')))
                {
                    $this->rest_format_data(
                        FALSE,
                        RESTFUL_BADREQUEST,
                        'return data type not understood - '.$this->return.'. Valid are hierarchical and normal [normal is default]'
                    );
                    return NULL;
                }



                $map = Array($entity);
                $args = func_get_args();
                $args = $args[1];



                if ($this->return == 'hierarchical')
                    $last_hierarchical_object = &$this->hierarchical_data;

                if (empty($args))
                {
                    /** return all records **/
                    $model->find();
                    if ($this->return == 'hierarchical')
                    {
                        $this->hierarchical_data [$entity] = $model->get_data();
                        $last_hierarchical_object = &$this->hierarchical_data [$entity];
                    }
                }
                else
                {
                    foreach ($args as $ka => $arg)
                    {
                        if (!is_numeric($arg))
                        {
                            /** reference entity not found */
                            if (!$model->is_mapable($arg))
                            {
                                $this->rest_format_data(
                                    FALSE,
                                    RESTFUL_BADREQUEST,
                                    'Bad request'
                                );
                                return;
                            }

                            if ($model->count == 0)
                            {
                                $this->rest_format_data(
                                    FALSE,
                                    RESTFUL_NOTFOUND,
                                    'Resource not found'
                                );
                                return;
                            }
                            //move to next mapable
                            $model = $model->{$arg};
                            if ($this->return == 'hierarchical')
                            {
                                $last_hierarchical_object[$arg] = $model->get_data();
                                $last_hierarchical_object = &$last_hierarchical_object[$arg][0];
                            }
                        }
                        else
                        if (is_numeric($arg) && intval($arg) > 0)
                        {
                            /** is numeric **/
                            $map[] = $model->table_name;
                            $model
                                ->clear()
                                ->limit(1)
                                ->find("`$model->table_key`=".intval($arg))
                            ;
                            if ($ka == 0 && $this->return == 'hierarchical')
                            {
                                $this->hierarchical_data [$entity] = $model->get_data();
                                $last_hierarchical_object = &$this->hierarchical_data [$entity][0];
                            }

                        }
                        else //is numeric and is <= 0
                        {
                            $this->rest_format_data(
                                FALSE,
                                RESTFUL_BADREQUEST,
                                'Bad request'
                            );
                            return;
                        }
                    }
                }

                if ($model->count == 0)
                {
                    $this->rest_format_data(
                        FALSE,
                        RESTFUL_NOTFOUND,
                        'Resource not found'
                    );
                    return;
                }

                if ($this->SYS->request_method == 'GET')
                {
                    $data = $this->return == 'hierarchical'
                                ? $this->hierarchical_data
                                : $model->get_data();

                    $this->rest_format_data(
                        TRUE,
                        $data
                    );
                }
                else
                if ($this->SYS->request_method == 'DELETE')
                {
                    $ids = $model->selected_keys;
                    $model->delete_all();

                    $this->rest_format_data(
                        TRUE,
                        Array(
                            'message' => 'Record(s) deleted from entity '.$model_name.' successfully',
                            'ids' => $ids,
                        )
                    );
                }
                else
                if ($this->SYS->request_method == 'PUT')
                {
                    $report = $model->eval_data($_POST);

                    if (!empty($report['errors']))
                    {
                        $this->rest_format_data(
                            FALSE,
                            RESTFUL_BADREQUEST,
                            Array(
                                'message' => 'Bad request - invalid or insufficient data. Check details',
                                'details' => $report['errors'],
                            )
                        );
                        return;
                    }
                    else
                    {
                        foreach ($report['ok'] as $field => $value)
                            $model->{$field} = $value;

                        $model->save();

                        $this->rest_format_data(
                            TRUE,
                            Array(
                                'message' => 'Record updated in entity '.$model_name.' successfully',
                                'id' => $model->{$model->table_key}
                            )
                        );
                    }



                }
            }
            else
            if ($this->SYS->request_method == 'POST')
            {
                if (!empty($this->ARGS))
                {
                    $this->rest_format_data(
                        FALSE,
                        RESTFUL_BADREQUEST,
                        'Invalid post request. Use single entity'
                    );
                    return;
                }

                $report = $model->eval_data($_POST);

                if (!empty($report['errors']))
                {
                    $this->rest_format_data(
                        FALSE,
                        RESTFUL_BADREQUEST,
                        Array(
                            'message' => 'Bad request - invalid or insufficient data. Check details',
                            'details' => $report['errors'],
                        )
                    );
                    return;
                }
                else
                {
                    $model->add($report['ok']);

                    if ($model->count > 0)
                    {
                        $this->rest_format_data(
                            TRUE,
                            Array(
                                'status' => RESTFUL_CREATED,
                                'message' => 'Record added to '.$model_name,
                                'id' => $model->{$model->table_key},
                            )
                        );
                    }
                    else
                    {
                        /** critical error has occured **/
                        $this->rest_format_data(
                            FALSE,
                            RESTFUL_UNSUPPORTEDENTITY,
                            'Unprocessible entity - some system level error has occured'
                        );
                        return;
                    }
                }
            }
            else
            {
                /** no extramethods **/
                $this->rest_format_data(
                    FALSE,
                    RESTFUL_NOTALLOWED,
                    'Method not allowed - allowed are : GET, POST, PUT/UPDATE & DELETE'
                );
                return;
            }
        }
    }



    