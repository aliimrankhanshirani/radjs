<?php

    class auth extends Controller
    {
        public $layout = 'default';
        
      
        public function main()
        {
            
            $this->render(
                'main',               
                'CONTENT'
            );
        }
        
        public function test()
        {
            return "I am test";
        }
    }


