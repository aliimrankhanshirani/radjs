<?php

    class home extends Controller
    {
        public $layout = 'default';
        
      
        public function main()
        {
            $c = Controller::instance('auth');
            
            
            $this->render(
                'main',               
                'CONTENT',
                $c->test()
            );
        }
    }


